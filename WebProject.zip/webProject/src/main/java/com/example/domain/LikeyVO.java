package com.example.domain;

import lombok.Data;

@Data
public class LikeyVO {
	private String userId;
	private String userSubJect;
	private String userIpAddr;

}
